To run playbooks, use the following format:

$ ansible-playbook -i <inventory_file> -u ansible <playbook>.yml
