#!/bin/bash

##########################################################################
#    Name         : backupCleanup_v3_cms.sh
#
#    Copyright (c)  2002-2020 "Neo4j"
#                   Neo4j Sweden AB [http://neo4j.com]
#                   This file is a commercial add-on to Neo4j Enterprise Edition.
#
#    Description  : This program will cleanup old backps based on retention time.
#
#    Input(s)     : The backup destination directory's full path.
#
#    Notes        :
##########################################################################
# User variables
#
. ${HOME}/neo4jcms/setenv_cms.sh

logFile=${CMS_HOME}/logs/backupCleanup.log 

# Specify the backup destination directory
backupFileDir="${NEO4J_BKUPDIR}"

# Set the backup file name
bname="${NEO4J_DB}-FullBackup-*"

# Set retention time in days
MTIME="+${NEO4J_BKUPRET}"

# Check if the log directory can be written to
#
logDir=`dirname ${logFile}`
if [ ! -w ${logDir} ]; then
        echo "The log file ${logFile} cannot be created"
        echo "Check if the path exists and also the permissions on the directory"
        exit 1
fi

#Cleanup old database backups after retention time (in days)
echo "Started cleanup of old backups (${bname}) from $backupFileDir at `date`" | ${TEE} -a ${logFile}
echo "" | ${TEE} -a ${logFile}
echo "List of old backups to remove from $backupFileDir at `date`" | ${TEE} -a ${logFile}
find ${backupFileDir} -maxdepth 1 -daystart -mtime ${MTIME} -name "${bname}" -type d -print | ${TEE} -a ${logFile}
echo "" | ${TEE} -a ${logFile}
echo "Removing old backups from $backupFileDir at `date`" | ${TEE} -a ${logFile}
##find ${backupFileDir} -maxdepth 1 -daystart -mtime ${MTIME} -name "${bname}" -type d -print -exec ${RM} -rf {} \; | ${TEE} -a ${logFile} #UNCOMMENT AFTER TESTING
echo "" | ${TEE} -a ${logFile}
echo "Completed cleanup of old backups (${bname}) from $backupFileDir at `date`" | ${TEE} -a ${logFile}
echo "" | ${TEE} -a ${logFile}

#Cleanup backup log files 
echo "Starting cleanup of old backup logs from ${CMS_HOME}/logs at `date`" | ${TEE} -a ${logFile}
echo "" | ${TEE} -a ${logFile}
echo "List of old backup logs to remove from $backupFileDir at `date`" | ${TEE} -a ${logFile}
find ${CMS_HOME}/logs -maxdepth 1 -daystart -mtime ${MTIME} -name "backupDatabase_*.log" -type f -print | ${TEE} -a ${logFile}
echo "" | ${TEE} -a ${logFile}
echo "Removing old backup logs from $backupFileDir at `date`" | ${TEE} -a ${logFile}
##find ${CMS_HOME}/logs -maxdepth 1 -daystart -mtime ${MTIME} -name "backupDatabase_*.log" -type f -print -exec ${RM} -rf {} \; | ${TEE} -a ${logFile} #UNCOMMENT AFTER TESTING
echo "" | ${TEE} -a ${logFile}
echo "Completed cleanup of old backup logs from ${CMS_HOME}/logs at `date`" | ${TEE} -a ${logFile}

exit 0
