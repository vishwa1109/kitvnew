#!/bin/bash

##########################################################################
#    Name         : backupDatabase_v4_cms.sh
#
#    Copyright (c)  2002-2020 "Neo4j"
#                   Neo4j Sweden AB [http://neo4j.com]
#                   This file is a commercial add-on to Neo4j Enterprise Edition.
#
#    Description  : This program uses "neo4j-admin backup" to backup an online EE database.
#
#    Input(s)     : The backup destination directory's full path.
#
#    Notes        : 
##########################################################################
# User variables
#
. ${HOME}/neo4jcms/setenv_cms.sh

# Uncomment the following JAVA_OPTS setting to avoid the JVM Warning:  
# OpenJDK 64-Bit Server VM warning: If the number of processors is expected to increase from one, 
# then you should configure the number of parallel GC threads appropriately using -XX:ParallelGCThreads=N
#
# NOTE: There may be a need to also set the following in the neo4j.conf file: dbms.jvm.additional=-XX:ParallelGCThreads=1
#
#export JAVA_OPTS='-XX:-AssumeMP'

timestamp=`date +%m%d%Y.%H:%M:%S`                       #POSSIBLY CHANGE ME
logFile=${CMS_HOME}/logs/backupDatabase_$timestamp.log  #POSSIBLY CHANGE ME

# Default databases to backup
dName="all"                                             #POSSIBLY CHANGE ME

# Default backup server and port
# WARNING: If using a remote IP address, ensure encryption is used to protect data over the network.
fromHost=localhost:6362                                 #POSSIBLY CHANGE ME

# Default heap and pachecache settings for backup
heapSize=2G                           #POSSIBLY CHANGE ME
pageCache=4G                          #POSSIBLY CHANGE ME

# DO NOT CHANGE
backupFileDir=""
bState=
cState=
copyState=
TMPFILE=/tmp/cfg$$

####
#### To send email notifications, uncomment the following variables
####
BACKUP_FROM="backup.job@${CUSTOMER}.${machine}"
EMAIL_HDR="To:${DBA_EMAIL}\nFrom:${BACKUP_FROM}"
#### Uncomment to here for email notifications

#########################################################################
#
# Function_name: usage_error
# Inputs:        None
# Purpose:       Will be invoked whenever script encounters
#                an invalid parameter or unhandled error
#
##########################################################################
function usage_error
{
   echo ""
   echo "usage: $0 -d <>"
   echo "     -d Full path to backup destination (Mandatory)"
   echo "     -n Database name ["db_name1 db_name2..."] : Default "all" (Optional)"
   echo "     -f Set From Host : Default localhost:6362 (Optional)"
   echo "     -c Run Consistency Check on backup [true] : Default false (Optional)"
   echo "     -b Set backup mode [incremental] : Default full (Optional)"
   echo "     -m Set HEAP_SIZE : Default 2G (Optional)"
   echo "     -p Set pache cache : Default 4G (Optional)"
   echo "     -h Print help message"
   echo
   exit 1
}

# First process all the command line options.
#
while getopts ":d:n:f:c:m:p:b:h"  nextarg
do
        case $nextarg in
                d ) backupFileDir=$OPTARG;;
                n ) dName=$OPTARG;;
                f ) fromHost=$OPTARG;;
                c ) ccheck=$OPTARG;;
                m ) heapSize=$OPTARG;;
                p ) pageCache=$OPTARG;;
                b ) vFull=$OPTARG;;
                h | \? ) usage_error;;
       esac
done
shift $(($OPTIND -1 ))

function isdbup
{
        # Uncomment the line below if Neo4j IS NOT running via console
        "${NEO4J_HOME}/bin/neo4j" status | grep "is running" > /dev/null
      
        # Uncomment the line below if Neo4j IS running via console
        # ps -ef | grep ${NEO4J_USER} | grep -v grep | grep java > /dev/null

        RET=$?
        #if [ $RET -eq 0 ]; then
        #   echo "Neo4j database processes are running"
        #fi

        return $RET
}

function checkDataDir
{
        dbDataDir=`cat $NEO4J_CONFDIR/neo4j.conf | grep "^dbms.directories.data" | cut -d"=" -f2` #> /dev/null
        if [ "$dbDataDir" = "" ]; then
           echo "Neo4j database data directory is set to the default $NEO4J_HOME/data or /var/lib/neo4j/data"
           echo
        else 
           echo "Neo4j database data directory is set to $dbDataDir in neo4j.conf"
           echo
        fi
}

function checkAuth
{
        dbAuth=`cat $NEO4J_CONFDIR/neo4j.conf | grep "^dbms.security.auth_enabled=" | ${CUT} -d"=" -f2 | tr [A-Z] [a-z]` #> /dev/null
        if [[ "$dbAuth" = "" || "$dbAuth" = "true" ]]; then
           checkConfig
           echo "-u ${_v1} -p ${_v2}"
        else
           echo "--non-interactive"
        fi
}

function checkBolt
{
        #dbMode=`cat $NEO4J_CONFDIR/neo4j.conf | grep "^dbms.mode=" | ${CUT} -d"=" -f2` #> /dev/null
        #if [[ "$dbMode" = "CORE" || "$dbMode" = "READ_REPLICA" ]]; then
           dbBolt=`cat $NEO4J_CONFDIR/neo4j.conf | grep "^dbms.connector.bolt.listen_address=" | ${CUT} -d"=" -f2` #> /dev/null
           if [[ "$dbBolt" = "" ]]; then
              connBolt="-a bolt://localhost:7687"
           else
              connBolt="-a bolt://$dbBolt"
           fi
        #else
        #   connBolt=""
        #fi
}

function checkConfig 
{
        if [  -f ${CPTFILE} ]; then
                ${NEOCAT} -c -k ${SVCFILE} ${CPTFILE}  > ${TMPFILE}
                . ${TMPFILE}
                \/bin/rm -f ${TMPFILE}
                return  0
        else
            echo "No cpt file found"
            exit 1
            return 1
        fi
}

function checkMem
{
        dbMem=`cat $NEO4J_CONFDIR/neo4j.conf | grep "^dbms.memory.pagecache.size" | ${CUT} -d"=" -f2 | tr [A-Z] [a-z]` #> /dev/null
        if [ "$dbMem" = "" ]; then
           echo "The dbms.memory.pagecache.size setting has not been configured." 
           echo "It is recommended that this setting is always explicitly configured, to ensure the system has a balanced configuration."
           echo "Run \"neo4j-admin memrec\" for memory configuration suggestions."
           echo
        fi
}

###########################################################
# Script starts here
###########################################################
echo

# Check if consistency check flag is set correctly if specified
# Set consistency check default to false if flag is not set
#
ccheck=`echo ${ccheck} | tr [A-Z] [a-z]`
if [ ! -z ${ccheck} ]; then
   if [ "${ccheck}" != "true" ]; then
   echo "-c option not set correctly"
   usage_error;
   fi
else
   ccheck=false
fi

# Check if full backup flag is set correctly if specified
#
vFull=`echo ${vFull} | tr [A-Z] [a-z]`
if [ ! -z ${vFull} ]; then
   if [ "${vFull}" != "incremental" ]; then
   echo "-b option not set correctly"
   usage_error;
   fi
fi

# Remove log file if it exists and recreate
#
if [ -e $logFile ]; then
rm $logFile
else
   touch $logFile
fi

# Check if the log directory can be written to
#
logDir=`dirname ${logFile}`
if [ ! -w ${logDir} ]; then
        echo "The log file ${logFile} cannot be created"
        echo "Check if the ${logDir} path exists and also the permissions on the directory"
        exit 2
fi

# Check if the Destination directory has been specified (it is mandatory)
#
if [ "${backupFileDir}" = "" ]; then
        echo "The backup destination directory has not been specified" | ${TEE} -a ${logFile}
        usage_error;
        exit 3
fi

# Check if the Destination directory exists
#
if [ ! -d "${backupFileDir}" ]; then
        echo "The backup destination directory specified does not exist" | ${TEE} -a ${logFile}
        usage_error;
        exit 4
fi

# Check if the Destination directory can be written to
#
if [ ! -w "${backupFileDir}" ]; then
        echo "The backup destination directory is not accessible" | ${TEE} -a ${logFile}
        echo "Check if the path exists and also the permissions on the directory" | ${TEE} -a ${logFile}
        exit 5
fi

#Check if Neo4j is UP and running
#
isdbup
if [ $? -ne 0 ]; then
   echo "The Neo4j database is shutdown, please start before attempting to backup" | ${TEE} -a ${logFile}
   echo "Backup Failed, database is shutdown at `date`" | ${TEE} -a ${logFile}
   if [ ! -z "$SENDMAIL" ]; then
                (echo -e "$EMAIL_HDR\n$SUBJ_F" ; cat $logFile ; ) | ${SENDMAIL} -f"${BACKUP_FROM}" "${DBA_EMAIL}";
   fi
   exit 6
fi

#Check the pagecache setting
#
checkMem | ${TEE} -a ${logFile}

# If backing up all databases, compile database list
#
if [ "${dName}" = "all" ]; then
checkConfig
if [ "${userName}" = "" ]; then
        userName=${appuser} 
fi

if [ "${userName}" = "" ]; then
   echo "Must specify connect Username for DB" | ${TEE} -a ${logFile}
   usage_error
else
      _v1=`echo ${userName} | cut -f1 -d/`
      _v2=`echo ${userName} | cut -f2 -d/`
      if [ $? -ne 0 ]; then
         print "Unable to connect to user ${userName} in the database" | ${TEE} -a ${logFile}
         exit 1
      fi
fi

#Check the bolt and auth_enabled settings
#
checkBolt
connMode=$(checkAuth)

aName=all
dName=(`${NEO4J_HOME}/bin/cypher-shell ${connBolt} ${connMode} -d system <<-EOF | ${SED} -e '1d' | ${CUT} -d, -f1 | ${SORT} -u | ${TR} '\n' ' ' | ${SED} "s/'//g" | ${SED} "s/\"//g"
SHOW DATABASES YIELD name, currentStatus WHERE currentStatus='online' RETURN name ORDER BY name;
EOF`)
else
dName=($dName)
fi

echo "Starting backup of databases at `date`" | ${TEE} -a ${logFile}
echo "The log of the backup process can be found at ${logFile}" | ${TEE} -a ${logFile}
echo | ${TEE} -a ${logFile}

# Explicitly set HEAP_SIZE
#
export HEAP_SIZE=${heapSize}

for i in "${dName[@]}"; do

# Check if the Destination directory exists
#
if [ ! -d "${logDir}/${i}" ]; then
   mkdir "${logDir}/${i}"
fi

# Remove log file if it exists and recreate
#
dblogFile=${logDir}/${i}/backupDatabase_${i}.log
if [ -e $dblogFile ]; then
rm $dblogFile
else
   touch $dblogFile
fi

# Check for incremental backup flag
#
obackupFileDir=${backupFileDir}
if [ "${vFull}" = "" ]; then
#  Default to full backup if incremental flag not specified
   backupFileDir=${backupFileDir}/${i}-FullBackup-$timestamp
   mode=full
else
# Set to static directory for incremental backup
   backupFileDir=${backupFileDir}/${i}-IncrementalBackup
   mode=incremental
fi

# Create backup directory if it does not exist
#
if [ ! -d "${backupFileDir}" ]; then
   mkdir ${backupFileDir}
fi

# Set mail subjects
#
SUBJ_S="Subject: ${NEO4J_BKUP_EMAIL_SUBJECT_PREFIX} ${i} SUCCESS at `date`\n"
SUBJ_F="Subject: ${NEO4J_BKUP_EMAIL_SUBJECT_PREFIX} ${i} FAILED at `date`\n"
SUBJ_W="Subject: ${NEO4J_BKUP_EMAIL_SUBJECT_PREFIX} ${i} SUCCESS WITH WARNING at `date`\n"
SUBJ_CF="Subject: ${CUSTOMER} - CONSISTENCY CHECK of ${i} on ${machine} FAILED at `date`\n"

echo | ${TEE} -a ${logFile}
echo "Starting ${mode} backup of ${i} database to ${backupFileDir} at `date`" | ${TEE} -a ${logFile}
echo | ${TEE} -a ${logFile}

#Check the size of the data directory
#
dbDataDir=`cat $NEO4J_CONFDIR/neo4j.conf | grep "^dbms.directories.data" | ${CUT} -d"=" -f2` #> /dev/null
checkDataDir | ${TEE} -a ${logFile}

if [ "${aName}" = "all" ]; then
 tSize=0
 # Check size of source directory (in KB)
 if [ "${dbDataDir}" = "" ]; then
   if [ -d ${NEO4J_HOME}/data ]; then
      sSize=`du -ks ${NEO4J_HOME}/data | ${CUT} -f1 | ${SED} -e 's/^[ \t]*//'`
   elif [ -d /var/lib/neo4j/data ]; then
      sSize=`du -ks /var/lib/neo4j/data | ${CUT} -f1 | ${SED} -e 's/^[ \t]*//'`
   fi
 else
   if [ ! -d "${NEO4J_HOME}/${dbDataDir}" -a ! -d "${dbDataDir}" ]; then
      echo "Data directory ${dbDataDir} does not exist, backup Failed at `date`" | ${TEE} -a ${logFile}
      if [ ! -z "$SENDMAIL" ]; then
         (echo -e "$EMAIL_HDR\n$SUBJ_F" ; cat $logFile ; ) | ${SENDMAIL} -f"${BACKUP_FROM}" "${DBA_EMAIL}";
      fi
      exit 7
   else
      if [ -d ${NEO4J_HOME}/${dbDataDir} ]; then
         sSize=`du -ks ${NEO4J_HOME}/${dbDataDir} | ${CUT} -f1 | ${SED} -e 's/^[ \t]*//'`
      else
         sSize=`du -ks ${dbDataDir} | ${CUT} -f1 | ${SED} -e 's/^[ \t]*//'`
      fi
   fi
 fi
else
 # Check size of source database directory (in KB)
 if [ "${dbDataDir}" = "" ]; then
   if [ -d ${NEO4J_HOME}/data/databases/${i} ]; then
      sSize=`du -ks ${NEO4J_HOME}/data/databases/${i} | ${CUT} -f1 | ${SED} -e 's/^[ \t]*//'`
      tSize=`du -ks ${NEO4J_HOME}/data/transactions/${i} | ${CUT} -f1 | ${SED} -e 's/^[ \t]*//'`
   elif [ -d /var/lib/neo4j/data ]; then
      sSize=`du -ks /var/lib/neo4j/data/databases/${i} | ${CUT} -f1 | ${SED} -e 's/^[ \t]*//'`
      tSize=`du -ks /var/lib/neo4j/data/transactions/${i} | ${CUT} -f1 | ${SED} -e 's/^[ \t]*//'`
   else
     echo "Data directory ${dbDataDir}/databases/${i} does not exist, backup Failed at `date`" | ${TEE} -a ${logFile}
      if [ ! -z "$SENDMAIL" ]; then
         (echo -e "$EMAIL_HDR\n$SUBJ_F" ; cat $logFile ; ) | ${SENDMAIL} -f"${BACKUP_FROM}" "${DBA_PAGER}";
      fi
      exit 8
   fi 
 else
   if [ ! -d "${NEO4J_HOME}/${dbDataDir}"/databases/${i} -a ! -d "${dbDataDir}"/databases/${i} ]; then
      echo "Data directory ${dbDataDir}/databases/${i} does not exist, backup Failed at `date`" | ${TEE} -a ${logFile}
      if [ ! -z "$SENDMAIL" ]; then
         (echo -e "$EMAIL_HDR\n$SUBJ_F" ; cat $logFile ; ) | ${SENDMAIL} -f"${BACKUP_FROM}" "${DBA_PAGER}";
      fi
      exit 9 
   else                 
      if [ -d ${NEO4J_HOME}/${dbDataDir}/databases/${i} ]; then
         sSize=`du -ks ${NEO4J_HOME}/${dbDataDir}/databases/${i} | ${CUT} -f1 | ${SED} -e 's/^[ \t]*//'`
         tSize=`du -ks ${NEO4J_HOME}/${dbDataDir}/transactions/${i} | ${CUT} -f1 | ${SED} -e 's/^[ \t]*//'`
      else
         sSize=`du -ks ${dbDataDir}/databases/${i} | ${CUT} -f1 | ${SED} -e 's/^[ \t]*//'`
         tSize=`du -ks ${dbDataDir}/transactions/${i} | ${CUT} -f1 | ${SED} -e 's/^[ \t]*//'`
      fi 
   fi 
 fi      
fi

# Compute total size of database and transaction directories
#
if [ "${sSize}" != "" ]; then
sSize="$(($sSize+$tSize))"
fi

# Check size of backup directory (in KB)
#
bSize=`${DF} -hk --output=avail ${backupFileDir} | ${SED} 1d | ${SED} -e 's/^[ \t]*//'`

# Check if backup location has sufficient space to hold the backup
#
if [ "${sSize}" -gt "${bSize}" ]; then
   echo "There is not enough space in ${backupFileDir} to perform backup, backup Failed at `date`" | ${TEE} -a ${logFile}
   echo | ${TEE} -a ${logFile}
   echo "End backup of databases at `date`" | ${TEE} -a ${logFile}
   if [ ! -z "$SENDMAIL" ]; then
                (echo -e "$EMAIL_HDR\n$SUBJ_F" ; cat $logFile ; ) | ${SENDMAIL} -f"${BACKUP_FROM}" "${DBA_EMAIL}";
   fi
   exit 10
fi

# For running backup where custom plugins exist, an empty plugin directory must be specified otherwise backup will fail
# setting dbms.directories.plugins explicitly to an empty directory in ${CMS_CONFDIR}/BKUP_neo4j_home/conf/neo4j.conf
export NEO4J_CONF=${CMS_CONFDIR}/BKUP_neo4j_home/conf

# Backup the database, explicitly set consistency-check to false and explicitly set pagecache
#
"${NEO4J_HOME}/bin/neo4j-admin" backup --from=${fromHost} --backup-dir="${backupFileDir}" --database=${i} --fallback-to-full=true --check-consistency=false --pagecache=${pageCache} 2>&1 | ${TEE} -a ${dblogFile} -a ${logFile}
RET=$?
# Check backup log for errors
#
grep -v "WARNING: Max 1024 open files allowed" ${dblogFile} | grep -e "ERROR" -e "error" -e "WARN" -e "failed" -e "ended with exception" -e "Exception in thread" -e "does not exist"
if [ $? -ne 0 -a $RET -eq 0 ]; then
  grep -q -e "Backup complete" ${dblogFile}
  if [ $? -ne 0 ]; then
     echo | ${TEE} -a ${logFile}
     echo "Backup Failed, backup not completed at `date`" | ${TEE} -a ${logFile}
     echo "Backup abnormally terminated ex. kill -9 at `date`" | ${TEE} -a ${logFile}
     copyState=1

     if [ ! -z "$SENDMAIL" ]; then
        (echo -e "$EMAIL_HDR\n$SUBJ_F" ; cat $dblogFile ; ) | ${SENDMAIL} -f"${BACKUP_FROM}" "${DBA_EMAIL}";
     fi
  else
     echo | ${TEE} -a ${logFile}
     echo "Backup Succeeded at `date`" | ${TEE} -a ${logFile}
     copyState=0
     bState=true
    if [ "${ccheck}" = "true" ]; then
        # If backup is successful and ccheck wasnt run, then run a consistency check against the backup
        #
        echo | ${TEE} -a ${logFile}
        cclogFile=${logDir}/${i}/backupCCheck_${i}.log
        if [ -e $cclogFile ]; then
            rm $cclogFile
            touch $cclogFile
        fi
        echo | ${TEE} -a ${logFile}
        echo "Starting backup consistency check at `date`" | ${TEE} -a ${logFile}
        echo | ${TEE} -a ${logFile}
		
		# For running check-consistency, HEAP settings are prioritized by the HEAP_SIZE env variable.
		# Be advised this value will be used to set BOTH inital and max heap settings.
		# It is worth noting that HEAP_SIZE will also OVERRIDE any heap settings in the NEO4J_CONF variable.
		# (effectively, the heap settings in NEO4J_CONF would NOT be used)
		export HEAP_SIZE=${heapSize}
		
		# For running check-consistency, PAGECACHE is controlled by 
		# setting dbms.memory.pagecache.size in ${CMS_CONFDIR}/CCHECK_neo4j_home/conf/neo4j.conf.
		export NEO4J_CONF=${CMS_CONFDIR}/CCHECK_neo4j_home/conf
		
        ${SCRIPT} -q -c "${NEO4J_HOME}/bin/neo4j-admin check-consistency --backup="${backupFileDir}/${i}" --report-dir=${logDir}/${i}" -f ${cclogFile} | ${TEE} -a ${logFile}
        RET=$?
        # Check for errors
        #
        grep -e "ERROR" -e "WARN" -e "failed" -e "consistency check did not complete" -e "Inconsistencies" -e "Exception in thread" ${cclogFile}
        if [ $? -eq 0 -o $RET -ne 0 ]; then
            echo | ${TEE} -a ${logFile}
            echo "Backup Succeeded, but consistency check Failed at `date`" | ${TEE} -a ${logFile}
            echo | ${TEE} -a ${logFile}
            if ls ${logDir}/${i}/*.report* 1> /dev/null 2>&1; then
                rVal=`ls -tr ${logDir}/${i}/*.report | tail -n 1` 
                cat ${rVal} | ${TEE} -a ${cclogFile}
            fi
            if [ ! -z "$SENDMAIL" ]; then
                (echo -e "$EMAIL_HDR\n$SUBJ_CF" ; cat $dblogFile ; cat $cclogFile ; ) | ${SENDMAIL} -f"${BACKUP_FROM}" "${DBA_EMAIL}";
            fi
        else 
           ##
		   ## The Neo4j Consistency Check log content changes over time.
		   ## Our RDBA Kit logic checks for the presence of a last line of the form:
		   ##    ................... 100%
		   ##
		   ## However, there is an issue that comes up in that the last line is not always the final status line
		   ## and we may actually see a blank line of the form (where "<blank line>" is an actual blank line in the log file):
		   ##    ................... 100%
		   ##    <blank line>
		   ## 
		   ## As of August 29, 2022 - in latest 4.x versions of Neo4j the "100%" comes on the 2nd to last line,
		   ## which has been documented here as "Scenario 1".  In the event that consistency check E-mails are showing
		   ## failure even though the log may show 100% completed with no errors, we may need to switch between 
		   ## "Scenario 1" and "Scenario 2" as Neo4j's implementation of the log output changes.  For now "Scenario 1" is our
		   ## default, and our team can comment / uncomment the scenarios below to adjust as needed.
		   ##
		   ## Scenario 1: Check for 100% on second to last line of the log file
		   cat ${cclogFile} | head -n -2 | tail -n 1 | grep -q -e "100%"
           ## Scenario 2: Check for 100% on the actual last line of the log file
		   #cat ${cclogFile} | tail -n 1 | grep -q -e "100%"
           if [ $? -ne 0 ]; then
              echo | ${TEE} -a ${logFile}
              echo "Backup Succeeded, but consistency check Failed at `date`" | ${TEE} -a ${logFile}
              echo | ${TEE} -a ${logFile}

              if [ ! -z "$SENDMAIL" ]; then
                (echo -e "$EMAIL_HDR\n$SUBJ_CF" ; cat $dblogFile ; cat $cclogFile ; ) | ${SENDMAIL} -f"${BACKUP_FROM}" "${DBA_EMAIL}";
              fi
           else
              echo | ${TEE} -a ${logFile}
              echo "Consistency check Succeeded at `date`" | ${TEE} -a ${logFile}

                # Backup was successful WITH CC, run backup cleanup
                #
                echo | ${TEE} -a ${logFile}
                echo "Backup cleanup (${i}) started at `date`" | ${TEE} -a ${logFile}
                echo | ${TEE} -a ${logFile}
                ${CMS_HOME}/backupCleanup_v4_cms.sh ${i} | ${TEE} -a ${logFile}
                echo | ${TEE} -a ${logFile}
                echo "Backup cleanup (${i}) completed at `date`" | ${TEE} -a ${logFile}
                
                bState=true
                cState=true
                #if [ ! -z "$SENDMAIL" ]; then
                #   (echo -e "$EMAIL_HDR\n$SUBJ_S" ; cat $dblogFile ; cat $cclogFile ; ) | ${SENDMAIL} -f"${BACKUP_FROM}" "${DBA_EMAIL}";
                #fi
            fi
        fi
    else
        # Backup was successful withOUT CC, run backup cleanup
        #
        echo | ${TEE} -a ${logFile}
        echo "Backup cleanup (${i}) started at `date`" | ${TEE} -a ${logFile}
        echo | ${TEE} -a ${logFile}
        ${CMS_HOME}/backupCleanup_v4_cms.sh ${i} | ${TEE} -a ${logFile}
        echo | ${TEE} -a ${logFile}
        echo "Backup cleanup (${i}) completed at `date`" | ${TEE} -a ${logFile}
        
        bState=true
        #if [ ! -z "$SENDMAIL" ]; then
        #   (echo -e "$EMAIL_HDR\n$SUBJ_S" ; cat $dblogFile ; cat $cclogFile ; ) | ${SENDMAIL} -f"${BACKUP_FROM}" "${DBA_EMAIL}";
        #fi
    fi
 fi

elif [ $RET -eq 1 ]; then
        echo | ${TEE} -a ${logFile}
        echo "Backup Failed with exit status 1 at `date`" | ${TEE} -a ${logFile}
        copyState=1
        echo | ${TEE} -a ${logFile}
        if [ ! -z "$SENDMAIL" ]; then
           (echo -e "$EMAIL_HDR\n$SUBJ_F" ; cat $dblogFile ; ) | ${SENDMAIL} -f"${BACKUP_FROM}" "${DBA_EMAIL}";
        fi
elif [ $RET -eq 2 ]; then
        echo | ${TEE} -a ${logFile}
        echo "Backup Succeeded, but consistency check Failed at `date`" | ${TEE} -a ${logFile}
        echo | ${TEE} -a ${logFile}
        if [ ! -z "$SENDMAIL" ]; then
           (echo -e "$EMAIL_HDR\n$SUBJ_W" ; cat $dblogFile ; ) | ${SENDMAIL} -f"${BACKUP_FROM}" "${DBA_EMAIL}";
        fi
elif [ $RET -eq 3 ]; then
        echo | ${TEE} -a ${logFile}
        echo "Backup Succeeded, but consistency check found inconsistencies at `date`" | ${TEE} -a ${logFile}
        echo | ${TEE} -a ${logFile}
        if [ ! -z "$SENDMAIL" ]; then
           (echo -e "$EMAIL_HDR\n$SUBJ_W" ; cat $dblogFile ; ) | ${SENDMAIL} -f"${BACKUP_FROM}" "${DBA_EMAIL}";
        fi
else
        echo | ${TEE} -a ${logFile}
        echo "Backup Failed with exit status $RET at `date`" | ${TEE} -a ${logFile}
        copyState=1
        echo | ${TEE} -a ${logFile}
        if [ ! -z "$SENDMAIL" ]; then
           (echo -e "$EMAIL_HDR\n$SUBJ_F" ; cat $dblogFile ; ) | ${SENDMAIL} -f"${BACKUP_FROM}" "${DBA_EMAIL}";
        fi
fi

echo | ${TEE} -a ${logFile}
echo "End backup of ${i} database to ${backupFileDir} at `date`" | ${TEE} -a ${logFile}

####
#### Insert code to copy backup to external storage here...
####

#if [ $copyState -eq 0 ]; then
#echo | ${TEE} -a ${logFile}
#echo "Copy ${i} database backup to S3"
#echo | ${TEE} -a ${logFile}

# Uncomment for AWS S3 copy
#
#AWS_BUCKET="s3://<s3_bucket_name>"    #CHANGE ME
#
#dir_name=`basename ${backupFileDir}`
#echo | ${TEE} -a ${logFile}
#echo "Starting ${mode} backup copy of ${i} database to S3 at `date`" | ${TEE} -a ${logFile}
#echo "Backup source directory: ${backupFileDir}" | ${TEE} -a ${logFile}
#echo "AWS S3 bucket: $AWS_BUCKET" | ${TEE} -a ${logFile}
#echo | ${TEE} -a ${logFile}
#if [ ! -d "${backupFileDir}" ]; then
#    echo | ${TEE} -a ${logFile}
#    echo "Backup directory ${backupFileDir} does not exist, S3 copy Failed at `date`" | ${TEE} -a ${logFile}
#else
#  # Copy backup to S3
#   ${AWS} s3 cp --recursive ${backupFileDir} $AWS_BUCKET/$dir_name  | ${TEE} -a ${logFile}
#  # Optional verify
#  #${AWS} s3 ls --recursive $AWS_BUCKET/$dir_name  | ${TEE} -a ${logFile}
#  echo "End backup copy of ${i} database to S3 at `date`"  | ${TEE} -a ${logFile}
#fi
#fi
#### End copy to external storage

# Send success backup email
#
if [ ! -z "$SENDMAIL" ]; then
 if [ ! -z "$bState" ]; then
  if [[ ${bState} = "true" && ${cState} = "true" ]]; then
     (echo -e "$EMAIL_HDR\n$SUBJ_S" ; cat $dblogFile ; cat $cclogFile ; ) | ${SENDMAIL} -f"${BACKUP_FROM}" "${DBA_EMAIL}";
  else
     (echo -e "$EMAIL_HDR\n$SUBJ_S" ; cat $dblogFile ; ) | ${SENDMAIL} -f"${BACKUP_FROM}" "${DBA_EMAIL}";
  fi
 fi
fi

# Reset variable to original backup directory
#
backupFileDir="${obackupFileDir}"

#Reset return code
#
RET=

# Reset state variables
#
bState=
cState=
copyState=

done

echo | ${TEE} -a ${logFile}
echo "End backup of databases at `date`" | ${TEE} -a ${logFile}

exit 0
