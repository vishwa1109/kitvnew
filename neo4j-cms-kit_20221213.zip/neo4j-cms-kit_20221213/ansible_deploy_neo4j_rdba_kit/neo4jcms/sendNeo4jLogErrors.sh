#!/bin/bash

##########################################################################
#    Name         : sendNeo4jLogErrors.sh
#
#    Copyright (c)  2002-2019 "Neo4j"
#                   Neo4j Sweden AB [http://neo4j.com]
#                   This file is a commercial add-on to Neo4j Enterprise Edition.
#
#    Description  : This program will parse the Neo4j neo4j.log for specifc errors.
#                 : This program will E-mail / Page Neo4j related alerts to the DBA
#
#    Input(s)     : The full path destination of the neo4j.log file.
#
#    Notes        : 
##########################################################################
# Script variables
#
. ${HOME}/neo4jcms/setenv_cms.sh

TMPDIR=${CMS_HOME}/tmp

logFile=${CMS_HOME}/logs/sendNeo4jLogErrors.log

neo4jLogErrorsFile=${CMS_HOME}/.config/neo4jLogErrors.neo4j
neo4jLogExcludeFile=${CMS_HOME}/.config/neo4jLogExclude.neo4j
neo4jLogPageFile=${CMS_HOME}/.config/neo4jLogPage.neo4j

#============================================================================
# Mail variables
#============================================================================
maildba="yes" # Set to "no" to supress email sending, set to yes to enable email

ALERT_FROM="alerts.neo4j@${CUSTOMER}.${machine}"

EMAIL_HDR_P="To:${DBA_PAGER}\nFrom:${ALERT_FROM}"
EMAIL_HDR="To:${DBA_EMAIL}\nFrom:${ALERT_FROM}"
SUBJ="Subject: $CUSTOMER - NEW neo4j log error detected on $machine at `date`\n"

###########################################################
# Script starts here
###########################################################
# Check if the full path destination of the neo4j.log file has been specified (it is mandatory)
#
if [ "$#" -ne 1 ]; then
    echo "Missing Argument. Please provide the full path destination of the neo4j.log file as the argument."
    exit 1
else
   if [ ! -f $1 ]; then
      echo "File $1 not found!"
      exit 2
   else
      file=$1
   fi
fi

# Check if the log directory can be written to
#
logDir=`dirname ${logFile}`
if [ ! -w ${logDir} ]; then
   echo "The log file ${logFile} cannot be created"
   echo "Check if the path exists and also the permissions on the directory"
   exit 3
fi

# Check if the temp directory can be written to
#
if [ ! -d ${TMPDIR} ]; then
   mkdir $TMPDIR
fi

#At this point all validations are complete. Time to start work.
echo "Starting neo4j log check at `date`" | ${TEE} -a ${logFile}

# The file called neo4jLogErrorsFile.neo4j contains strings to check for
# The file called neo4jLogExcludeFile.neo4j contains strings to ignore
# The file called neo4jLogPage.neo4j contains strings to send pages on

cat $file | awk -f ${neo4jLogErrorsFile} | sed -f ${neo4jLogExcludeFile} >> ${TMPDIR}/neo4jErrors.neo4j

# Check if there are any new errors
numErrors=`wc -l ${TMPDIR}/neo4jErrors.neo4j | awk '{print $1}'`
if [ ${numErrors} -ne 0 -a $maildba = "yes" ]; then

# We really don't want to turn this off unless we are getting overwhelmed
   #if new errors is > 0 then send E-mail
   newErrors=`${DIFF} ${TMPDIR}/neo4jErrors.neo4j ${TMPDIR}/neo4jErrors.old | wc -l | awk '{print $1}'`

  if [ $newErrors -ne 0 ]; then
    # Check for pageable alerts
    ${DIFF} ${TMPDIR}/neo4jErrors.neo4j ${TMPDIR}/neo4jErrors.old >> ${TMPDIR}/neo4jErrors.tmp
    numPageErrors=`cat ${TMPDIR}/neo4jErrors.tmp | awk -f ${neo4jLogPageFile} | wc -l | awk '{print $1}'`
    if [ ${numPageErrors} -ne 0 ]; then
       echo "$CUSTOMER - NEW neo4j log error detected on $machine at `date`" >> ${logFile}
       (echo -e "$EMAIL_HDR_P\n$SUBJ" ; $DIFF -c $TMPDIR/neo4jErrors.old $TMPDIR/neo4jErrors.neo4j | sed 1,5d ; ) | ${SENDMAIL} -f"${ALERT_FROM}" "${DBA_PAGER}";
       ${RM} ${TMPDIR}/neo4jErrors.tmp
    else
       echo "$CUSTOMER - NEW neo4j log error detected on $machine at `date`" >> ${logFile}
      (echo -e "$EMAIL_HDR\n$SUBJ" ; $DIFF -c $TMPDIR/neo4jErrors.old $TMPDIR/neo4jErrors.neo4j | sed 1,5d ; ) | ${SENDMAIL} -f"${ALERT_FROM}" "${DBA_EMAIL}";
       ${RM} ${TMPDIR}/neo4jErrors.tmp
    fi
  fi
fi

${MV} ${TMPDIR}/neo4jErrors.neo4j ${TMPDIR}/neo4jErrors.old

exit 0;

