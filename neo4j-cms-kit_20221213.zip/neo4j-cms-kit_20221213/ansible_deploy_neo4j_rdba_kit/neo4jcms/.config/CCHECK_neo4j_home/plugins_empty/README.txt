
This is a special directory for running CCHECK as part of the Neo4j RDBA Kit.

Do NOT put any plugins in this directory, keep it EMPTY.
