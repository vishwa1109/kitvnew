#!/bin/bash

##########################################################################
#    Name         : sendDebugLogErrors.sh
#
#    Copyright (c)  2002-2019 "Neo4j"
#                   Neo4j Sweden AB [http://neo4j.com]
#                   This file is a commercial add-on to Neo4j Enterprise Edition.
#
#    Description  : This program will parse the Neo4j debug.log for specifc errors.
#                 : This program will E-mail / Page Neo4j related alerts to the DBA
#
#    Input(s)     : The full path destination of the debug.log file.
#
#    Notes        : 
##########################################################################
# Script variables
#
. ${HOME}/neo4jcms/setenv_cms.sh

TMPDIR=${CMS_HOME}/tmp

logFile=${CMS_HOME}/logs/sendDebugLogErrors.log

debugLogErrorsFile=${CMS_HOME}/.config/debugLogErrors.neo4j
debugLogExcludeFile=${CMS_HOME}/.config/debugLogExclude.neo4j
debugLogPageFile=${CMS_HOME}/.config/debugLogPage.neo4j

#============================================================================
# Mail variables
#============================================================================
maildba="yes" # Set to "no" to supress email sending, set to yes to enable email

ALERT_FROM="alerts.neo4j@${CUSTOMER}.${machine}"

EMAIL_HDR_P="To:${DBA_PAGER}\nFrom:${ALERT_FROM}"
EMAIL_HDR="To:${DBA_EMAIL}\nFrom:${ALERT_FROM}"
SUBJ="Subject: $CUSTOMER - NEW debug log error detected on $machine at `date`\n"

###########################################################
# Script starts here
###########################################################
# Check if the full path destination of the debug.log file has been specified (it is mandatory)
#
if [ "$#" -ne 1 ]; then
    echo "Missing Argument. Please provide the full path destination of the debug.log file as the argument."
    exit 1
else
   if [ ! -f $1 ]; then
      echo "File $1 not found!"
      exit 2
   else
      file=$1
   fi
fi

# Check if the log directory can be written to
#
logDir=`dirname ${logFile}`
if [ ! -w ${logDir} ]; then
   echo "The log file ${logFile} cannot be created"
   echo "Check if the path exists and also the permissions on the directory"
   exit 3
fi

# Check if the temp directory can be written to
#
if [ ! -d ${TMPDIR} ]; then
   mkdir $TMPDIR
fi

#At this point all validations are complete. Time to start work.
echo "Starting debug log check at `date`" | ${TEE} -a ${logFile}

# The file called debugLogErrorsFile.neo4j contains strings to check for
# The file called debugLogExcludeFile.neo4j contains strings to ignore
# The file called debugLogPage.neo4j contains strings to send pages on

cat $file | awk -f ${debugLogErrorsFile} | sed -f ${debugLogExcludeFile} >> ${TMPDIR}/debugErrors.neo4j

# Check if there are any new errors
numErrors=`wc -l ${TMPDIR}/debugErrors.neo4j | awk '{print $1}'`
if [ ${numErrors} -ne 0 -a $maildba = "yes" ]; then

# We really don't want to turn this off unless we are getting overwhelmed
   #if new errors is > 0 then send E-mail
   newErrors=`${DIFF} ${TMPDIR}/debugErrors.neo4j ${TMPDIR}/debugErrors.old | wc -l | awk '{print $1}'`

  if [ $newErrors -ne 0 ]; then
    # Check for pageable alerts
    ${DIFF} ${TMPDIR}/debugErrors.neo4j ${TMPDIR}/debugErrors.old >> ${TMPDIR}/debugErrors.tmp
    numPageErrors=`cat ${TMPDIR}/debugErrors.tmp | awk -f ${debugLogPageFile} | wc -l | awk '{print $1}'`
    if [ ${numPageErrors} -ne 0 ]; then
       echo "$CUSTOMER - NEW debug log error detected on $machine at `date`" >> ${logFile}
       (echo -e "$EMAIL_HDR_P\n$SUBJ" ; $DIFF -c $TMPDIR/debugErrors.old $TMPDIR/debugErrors.neo4j | sed 1,5d ; ) | ${SENDMAIL} -f"${ALERT_FROM}" "${DBA_PAGER}";
       ${RM} ${TMPDIR}/debugErrors.tmp
    else
       echo "$CUSTOMER - NEW debug log error detected on $machine at `date`" >> ${logFile}
      (echo -e "$EMAIL_HDR\n$SUBJ" ; $DIFF -c $TMPDIR/debugErrors.old $TMPDIR/debugErrors.neo4j | sed 1,5d ; ) | ${SENDMAIL} -f"${ALERT_FROM}" "${DBA_EMAIL}";
       ${RM} ${TMPDIR}/debugErrors.tmp
    fi
  fi
fi

${MV} ${TMPDIR}/debugErrors.neo4j ${TMPDIR}/debugErrors.old

exit 0;

