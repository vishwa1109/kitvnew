The Neo4j process check panels need to be updated.

See the updates for checking "neo4j_vm_thread_total" in "Moon Active Neo4j DR-1603978309135.json".

Merge these changes back in to our templates.
