#!/bin/bash

. ${HOME}/neo4jcms/setenv_cms.sh

DBA_EMAIL="<!!!!CHANGE_ME_BEFORE_TESTING!!!!>"

ALERT_FROM="alerts.neo4j@$CUSTOMER.$machine"

EMAIL_HDR="To:${DBA_EMAIL}\nFrom:${ALERT_FROM}"
SUBJ="Subject: Test from $CUSTOMER.$machine at `date`\n"

SENDMAIL=/usr/sbin/sendmail

(echo -e "$EMAIL_HDR\n$SUBJ") | ${SENDMAIL} -f"${ALERT_FROM}" "${DBA_EMAIL}"
