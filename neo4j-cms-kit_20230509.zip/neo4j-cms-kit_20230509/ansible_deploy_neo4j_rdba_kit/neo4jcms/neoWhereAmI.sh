#!/bin/bash

##########################################################################
#    Name         : neoWhereAmI.sh
#
#    Copyright (c)  2002-2020 "Neo4j"
#                   Neo4j Sweden AB [http://neo4j.com]
#                   This file is a commercial add-on to Neo4j Enterprise Edition.
#
#    Description  : This program reports "whereAmI" information (current system, current database)
##########################################################################

if [ -f ${HOME}/neo4jcms/setenv_cms.sh ]; then
    . ${HOME}/neo4jcms/setenv_cms.sh		
else
	echo "No setenv file found"
	exit 1
fi

if [ -z "${CMS_HOME}" ] || [ -z "${CPTFILE}" ] || [ -z "${NEOCAT}" ] || [ -z "${RM}" ] || [ -z "${SVCFILE}" ]; then
	echo "The setenv infrastructure is not setup correctly, please review variable configuration"
	exit 1    
fi        

if [ ! -f "${CPTFILE}" ] || [ ! -f "${NEOCAT}" ] || [ ! -f "${SVCFILE}" ]; then
	echo "The setenv infrastructure is not setup correctly, please review file configuration"
	exit 1    
fi        

TMPFILE=/tmp/neoWhereAmI$$

function isdbup
{
        # Uncomment the line below if Neo4j IS NOT running via console
        "${NEO4J_HOME}/bin/neo4j" status | grep "is running" > /dev/null
      
        # Uncomment the line below if Neo4j IS running via console
        # ps -ef | grep ${NEO4J_USER} | grep -v grep | grep java > /dev/null

        RET=$?
        #if [ $RET -eq 0 ]; then
        #   echo "Neo4j database processes are running"
        #fi

        return $RET
}

function checkConfig 
{
        if [  -f ${CPTFILE} ]; then
                ${NEOCAT} -c -k ${SVCFILE} ${CPTFILE}  > ${TMPFILE}
                . ${TMPFILE}
                \/bin/rm -f ${TMPFILE}
                return  0
        else
            echo "No cpt file found"
            exit 2
            return 1
        fi
}

function getAuth
{
    echo "-u ${_v1} -p ${_v2}"
}

###########################################################
# Script starts here
###########################################################

if [ "${CUSTOMER}" = "" ]; then
   echo "Could not retrieve Customer Name, please check environment settings"
   exit 3
fi

if [ "${CUSTOMER_PROJECT_NAME}" = "" ]; then
   echo "Could not retrieve Customer Project Name, please check environment settings"
   exit 4
fi

if [ "${CUSTOMER_ENVIRONMENT_TYPE}" = "" ]; then
   echo "Could not retrieve Customer Environment Type, please check environment settings"
   exit 5
fi

echo ""
echo "***** Began neoWhereAmI at $(date) *****"

echo ""
echo "---------------------------------------------------"
echo "----- Customer Environment Info -------------------"
echo "---------------------------------------------------"
echo ""
echo "Customer Name:     ${CUSTOMER}"
echo "Project Name:      ${CUSTOMER_PROJECT_NAME}"
echo "Environment Type:  ${CUSTOMER_ENVIRONMENT_TYPE}"

echo ""
echo "---------------------------------------------------"
echo "----- Operating System Connection Info ------------"
echo "---------------------------------------------------"
echo ""
echo "Hostname:          $(hostname)"
echo "IP Address:        $(hostname -I | awk '{print $1}')"
echo "OS User:           $(whoami)"

isdbup
if [ $? -ne 0 ]; then
   echo ""
   echo "---------------------------------------------------"
   echo "----- Neo4j Database Connection Info --------------"
   echo "---------------------------------------------------"
   echo ""
   echo "The Neo4j database is OFFLINE"
   echo ""
   exit 6
fi

checkConfig
if [ "${userName}" = "" ]; then
        userName=${appuser} 
fi

if [ "${userName}" = "" ]; then
   echo "Could not retrieve userName for database connection"
   exit 7
else
      _v1=`echo ${userName} | cut -f1 -d/`
      _v2=`echo ${userName} | cut -f2 -d/`
fi

echo ""
echo "---------------------------------------------------"
echo "----- Neo4j Database Connection Info --------------"
echo "---------------------------------------------------"
echo ""
connMode=$(getAuth)
${NEO4J_HOME}/bin/cypher-shell -a bolt://localhost:7687 ${connMode} --format verbose <<-EOF > ${TMPFILE}
CALL   dbms.components() 
YIELD  versions 
UNWIND versions as version
WITH   version
CALL   apoc.do.case(
        [version Starts with "4", "call db.info() yield name return name as value"],
        "CALL dbms.listConfig() YIELD name, value as v1 where name in ['dbms.active_database','dbms.default_database'] return v1 as value"
	   )
  YIELD  value 
  RETURN 'Database Name' as name,
         value.value     as value
UNION
CALL    dbms.listConfig()
YIELD   name, value
WHERE   name="dbms.mode"
RETURN  CASE 
		  WHEN name = "dbms.mode"                             THEN 'Database Mode'
          ELSE name 
        END as name,
        CASE 
          WHEN name = "dbms.mode" and value = "SINGLE"        THEN 'Standalone'
          WHEN name = "dbms.mode" and value = "CORE"          THEN 'Cluster (CORE)'
		  WHEN name = "dbms.mode" and value = "READ_REPLICA"  THEN 'Cluster (RR)'
          ELSE value 
        END as value
ORDER BY name
UNION
call dbms.components()      yield versions unwind versions as version return 'Database Version' as name, version as value
UNION
call dbms.showCurrentUser() yield username return 'Current User' as name,username as value;
EOF

echo "Database Name:     $(grep "Database Name" ${TMPFILE}    | cut -d "|" -f 3 | xargs)"
echo "Database Mode:     $(grep "Database Mode" ${TMPFILE}    | cut -d "|" -f 3 | xargs)"
echo "Database Version:  $(grep "Database Version" ${TMPFILE} | cut -d "|" -f 3 | xargs)"
echo "Database User:     $(grep "Current User" ${TMPFILE}     | cut -d "|" -f 3 | xargs)"
echo ""

${RM} -f ${TMPFILE}

echo "***** Ended neoWhereAmI at $(date) *****"
echo ""

exit 0
